//
//  CryptoSwift.h
//  CryptoSwift
//
//  Created by Sam Soffes on 11/29/15.
//  Copyright © 2015 Marcin Krzyzanowski. All rights reserved.
//

@import Foundation;

//! Project version number for CryptoSwift.
FOUNDATION_EXPORT double CryptoSwiftVersionNumber;

//! Project version string for CryptoSwift.
FOUNDATION_EXPORT const unsigned char CryptoSwiftVersionString[];
